#ifndef VARIABLEARRAYIDS_H
#define VARIABLEARRAYIDS_H

namespace varids
{
  enum types
    {
      TECHITV1 = 6000,
      G4VTXV1 = 1,
      G4PARTICLEV1 = 2
    };
};

#endif

#ifndef SYNCDEFS_H__
#define SYNCDEFS_H__

namespace syncdefs
{
  static const int NUM_SYNC_VARS=4;
  static const char *SYNCVARS[] = { "eventcounter", "eventnumber", "runnumber", "segmentnumber"};
}

#endif
